import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const experiences = JSON.parse(fs.readFileSync(path.join(__dirname, "silas_experiences.json"), "utf8"));

function findSilasExperience(subject, question) {
  const text = `${subject} ${question}`.toLowerCase();
  return experiences.find(item => item.subject.toLowerCase() === subject.toLowerCase() && item.topics.some(topic => text.includes(topic.toLowerCase()))) ?? null;
}

const accuracyRules = `
CORE SILAS STEM PRINCIPLE:
"As a science student, I have to follow laws and use theoretically accurate formulas. I should not guess an answer just because it looks right."
Use accepted mathematical, scientific, and computer-science principles. Never invent formulas, laws, definitions, equations, or facts. State the relevant law/formula/concept when appropriate. Check units, signs, ratios, assumptions, and arithmetic. If information is missing or ambiguous, say so rather than guessing.
`;

app.use(express.json({ limit: "1mb" }));
app.use(express.static(__dirname));

app.post("/api/solve", async (req, res) => {
  try {
    const { question, subject = "Mathematics", difficulty = "Beginner" } = req.body ?? {};
    if (typeof question !== "string" || !question.trim()) return res.status(400).json({ error: "Please enter a question." });
    const matched = findSilasExperience(subject, question);
    const experience = matched ? `Experience: ${matched.experience}\nTip: ${matched.tip}` : `No matching experience. Say: "Silas hasn't added an experience for this topic yet." Do not invent one.`;
    const instructions = `You are the STEM tutor for Learn STEM with Silas. Subject: ${subject}. Difficulty: ${difficulty}.\n${accuracyRules}\nSolve and teach. Use: 1. What is given 2. What is required 3. Relevant formula/concept 4. Step-by-step working 5. Final answer 6. Simple explanation 7. Silas's Experience 8. Silas's Tip.\nSilas's Experience must only come from this owner-supplied content; never invent or falsely paraphrase a personal event:\n${experience}`;
    const response = await client.responses.create({ model: process.env.OPENAI_MODEL || "gpt-6-luna", instructions, input: question.trim() });
    res.json({ answer: response.output_text });
  } catch (error) { console.error(error); res.status(500).json({ error: "The AI solver could not process the question right now." }); }
});

async function aiMode(req, res, mode) {
  try {
    const { question, subject = "Mathematics", difficulty = "Beginner", attempt = "" } = req.body ?? {};
    if (typeof question !== "string" || !question.trim()) return res.status(400).json({ error: "Please enter a question first." });
    const matched = findSilasExperience(subject, question);
    const experience = matched ? `Use only this real Silas experience if relevant: ${matched.experience}\nTip: ${matched.tip}` : `No matching Silas experience exists. Do not invent one.`;
    let task;
    if (mode === "hint") task = `Give a progressive hint for this question. Do NOT give the final answer or complete solution. Start with one useful clue, then a second clue only if needed. Point the student toward the correct law/formula/concept.`;
    if (mode === "teach") task = `Teach the concept behind this question from the basics. Explain the idea, relevant law/formula, why it applies, a small worked example if useful, common mistake, then explain how the student should approach the given question. Do not merely output the answer.`;
    if (mode === "practice") task = `Create ONE new practice question testing the same concept at ${difficulty} level, but with different values/context. Give the question first, then a short answer-check section hidden conceptually by labeling it "Answer key" after a separator. If the student supplied an attempt, mark it and explain the mistake or confirm it. Attempt: ${attempt || "No attempt yet"}`;
    const instructions = `You are an accurate STEM tutor for Learn STEM with Silas. Subject: ${subject}. Difficulty: ${difficulty}.\n${accuracyRules}\n${task}\n${experience}`;
    const response = await client.responses.create({ model: process.env.OPENAI_MODEL || "gpt-6-luna", instructions, input: question.trim() });
    res.json({ answer: response.output_text, mode });
  } catch (error) { console.error(error); res.status(500).json({ error: "The AI mode could not run right now." }); }
}

app.post("/api/hint", (req, res) => aiMode(req, res, "hint"));
app.post("/api/teach", (req, res) => aiMode(req, res, "teach"));
app.post("/api/practice", (req, res) => aiMode(req, res, "practice"));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Learn STEM with Silas running at http://localhost:${port}`));
